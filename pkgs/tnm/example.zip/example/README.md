Use this example to develop your own app for EnforceOS, basically just fill-in-the-blank.
Using your JavaScript skills, you can make nearly anything from a game to a basic weather app.